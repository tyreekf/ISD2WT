function demoA () { alert(" You are now logging out  "); }

