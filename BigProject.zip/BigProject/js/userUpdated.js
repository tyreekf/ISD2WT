function UserUpdated() {
    alert("Updated !");
  }