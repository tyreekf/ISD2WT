function Contact() {
    alert("Thanks for contacting , we will respond soon !");
  }